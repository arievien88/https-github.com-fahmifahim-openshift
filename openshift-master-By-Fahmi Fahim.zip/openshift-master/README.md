## Repository for Red Hat OpenShift Container Platform (OCP 3.x and 4.x) cheatsheet
Lets go to the [cheatsheet.md](https://github.com/fahmifahim/openshift/blob/master/01.openshift-cheatsheet.md) file
